//
//  Examen_P2Tests.swift
//  Examen_P2Tests
//
//  Created by Zurisabdai Núñez Velázquez on 27/10/25.
//

import Testing
@testable import Examen_P2

struct Examen_P2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
