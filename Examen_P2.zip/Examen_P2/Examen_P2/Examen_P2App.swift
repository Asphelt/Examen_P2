//
//  Examen_P2App.swift
//  Examen_P2
//
//  Created by Zurisabdai Núñez Velázquez on 27/10/25.
//

import SwiftUI

@main
struct Examen_P2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
