//
//  GroupBoxView.swift
//  Examen_P2
//
//  Created by Zurisabdai Núñez Velázquez on 27/10/25.
//

import SwiftUI

struct GroupBoxView: View {
    var body: some View {
    }
}

#Preview {
    GroupBoxView()
}
